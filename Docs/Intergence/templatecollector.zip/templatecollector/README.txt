What this is
------------

This Template Collector provides a simple example of a HyperGlance programmatic collector.

What this is not
-----------------

The Template Collector is not a full example of all possible HyperGlance collector functionality 
(there are no refinement classes and no examples of SQL collection based on queries in the 
collector-jboss-beans.xml). 

A full description of HyperGlance collector functionality can be found in the "HyperGlance Collectors.docx" 
in the release bundle.

Contents of the template collector
-----------------------------------

- lib
Add any java .jar files that your collector may require.
The ant build files will deploy .jar files from this directory.

- META-INF
The HG server deployment descriptors.

The collector-jboss-beans.xml is of particular interest. 
It's described in full in the "HyperGlance Collectors.docx" which will be in your release bundle.

- src
The java source files. 
These are well documented stubs containing trivial example code.

They should serve as reasonable starting points for writing a programmatic collector.

- .classpath
An eclipse project metadata file - handy if you want to import the collector into the eclipse IDE

- .project
An eclipse project metadata file - handy if you want to import the collector into the eclipse IDE
(you may want to modify this one if you want to change the name of your collector project)

- build.properties
Ant build properties file. Described in the section on "Building the template collector" below.

- build.xml
Ant build script. Described in the section on "Building the template collector" below.

IMPORTANT NOTE:
This collector depends on the existance of core HyperGlance collector libraries in the "collector-corelibs" project.
By default the collector-corelibs project is expected to be unpacked alongside this collector.
This is our current crude mechanism for sharing core libraries across several collectors.


Building the template collector
-------------------------------

The template collector contains a simple ant build script.

build.properties:

- ensure that the jboss.home property is correctly set for your environment.
- modify the deployment.name property to whatever you'd like your collector to be called 
(this must end in .ear and may not contain spaces or path separators)

build.xml:

This is the ant build script.

To deploy the collector simply run "ant", you'll see output similar to the following:

C:\dev\templatecollector>ant
Buildfile: C:\dev\templatecollector\build.xml

clean:
   [delete] Deleting directory C:\dev\templatecollector\build

prepare:
    [mkdir] Created dir: C:\dev\templatecollector\build\classes

compile-project:
    [javac] C:\dev\templatecollector\build.xml:50: warning: 'includeantruntime'
was not set, defaulting to build.sysclasspath=last; set to false for repeatable
builds
    [javac] Compiling 3 source files to C:\dev\templatecollector\build\classes
    [javac] [parsing started C:\dev\templatecollector\src\com\acme\TopologyDisco
verer.java]
    [javac] [parsing completed 35ms]
    [javac] [parsing started C:\dev\templatecollector\src\com\acme\metrics\Metri
csDiscoverer.java]
    [javac] [parsing completed 5ms]
    [javac] [parsing started C:\dev\templatecollector\src\com\acme\metrics\TimeS
eriesMetricsFetcher.java]
    [javac] [parsing completed 5ms]
    [javac] [search path for source files: C:\dev\templatecollector\src]
    [javac] [search path for class files: C:\Java\jdk1.6.0_22\jre\lib\resources.
jar,C:\Java\jdk1.6.0_22\jre\lib\rt.jar,C:\Java\jdk1.6.0_22\jre\lib\sunrsasign.ja
r,C:\Java\jdk1.6.0_22\jre\lib\jsse.jar,C:\Java\jdk1.6.0_22\jre\lib\jce.jar,C:\Ja
va\jdk1.6.0_22\jre\lib\charsets.jar,C:\Java\jdk1.6.0_22\jre\classes,C:\Java\jdk1
.6.0_22\jre\lib\ext\dnsns.jar,C:\Java\jdk1.6.0_22\jre\lib\ext\localedata.jar,C:\
Java\jdk1.6.0_22\jre\lib\ext\sunjce_provider.jar,C:\dev\templatecollector\build\
classes,C:\dev\collector-corelibs\lib\commons-lang-2.6.jar,C:\dev\collector-core
libs\lib\guava-r09.jar,C:\dev\collector-corelibs\lib\hyperglance-api-1.3.jar,C:\
dev\collector-corelibs\lib\jboss-common-core.jar,C:\dev\collector-corelibs\lib\j
boss-kernel.jar,C:\dev\collector-corelibs\lib\log4j-1.2.16.jar,C:\apache-ant-1.8
.1\lib\ant-launcher.jar,C:\dev\templatecollector,C:\Program Files (x86)\Java\jre
6\lib\ext\QTJava.zip,C:\apache-ant-1.8.1\lib\ant-antlr.jar,C:\apache-ant-1.8.1\l
ib\ant-apache-bcel.jar,C:\apache-ant-1.8.1\lib\ant-apache-bsf.jar,C:\apache-ant-
1.8.1\lib\ant-apache-log4j.jar,C:\apache-ant-1.8.1\lib\ant-apache-oro.jar,C:\apa
che-ant-1.8.1\lib\ant-apache-regexp.jar,C:\apache-ant-1.8.1\lib\ant-apache-resol
ver.jar,C:\apache-ant-1.8.1\lib\ant-apache-xalan2.jar,C:\apache-ant-1.8.1\lib\an
t-commons-logging.jar,C:\apache-ant-1.8.1\lib\ant-commons-net.jar,C:\apache-ant-
1.8.1\lib\ant-jai.jar,C:\apache-ant-1.8.1\lib\ant-javamail.jar,C:\apache-ant-1.8
.1\lib\ant-jdepend.jar,C:\apache-ant-1.8.1\lib\ant-jmf.jar,C:\apache-ant-1.8.1\l
ib\ant-jsch.jar,C:\apache-ant-1.8.1\lib\ant-junit.jar,C:\apache-ant-1.8.1\lib\an
t-netrexx.jar,C:\apache-ant-1.8.1\lib\ant-nodeps.jar,C:\apache-ant-1.8.1\lib\ant
-swing.jar,C:\apache-ant-1.8.1\lib\ant-testutil.jar,C:\apache-ant-1.8.1\lib\ant.
jar,C:\Java\jdk1.6.0_22\lib\tools.jar]
    [javac] [loading java\util\HashMap.class(java\util:HashMap.class)]
    [javac] [loading java\util\Map.class(java\util:Map.class)]
    [javac] [loading com\realstatus\hgs\collection\CollectorPluginDescriptor.cla
ss(com\realstatus\hgs\collection:CollectorPluginDescriptor.class)]
    [javac] [loading com\realstatus\hgs\collection\DiscoveryExecutor.class(com\r
ealstatus\hgs\collection:DiscoveryExecutor.class)]
    [javac] [loading com\realstatus\hgs\model\lookup\ModelLookup.class(com\reals
tatus\hgs\model\lookup:ModelLookup.class)]
    [javac] [loading com\realstatus\hgs\model\update\ModelUpdate.class(com\reals
tatus\hgs\model\update:ModelUpdate.class)]
    [javac] [loading java\lang\Object.class(java\lang:Object.class)]
    [javac] [loading java\util\ArrayList.class(java\util:ArrayList.class)]
    [javac] [loading java\util\Collection.class(java\util:Collection.class)]
    [javac] [loading java\util\Date.class(java\util:Date.class)]
    [javac] [loading java\util\concurrent\ConcurrentHashMap.class(java\util\conc
urrent:ConcurrentHashMap.class)]
    [javac] [loading com\realstatus\hgs\collection\BatchGroup.class(com\realstat
us\hgs\collection:BatchGroup.class)]
    [javac] [loading com\realstatus\hgs\collection\PerformanceExecutor.class(com
\realstatus\hgs\collection:PerformanceExecutor.class)]
    [javac] [loading com\realstatus\hgs\model\metric\DefaultMetricDescriptor.cla
ss(com\realstatus\hgs\model\metric:DefaultMetricDescriptor.class)]
    [javac] [loading com\realstatus\hgs\model\metric\DefaultMetricValue.class(co
m\realstatus\hgs\model\metric:DefaultMetricValue.class)]
    [javac] [loading com\realstatus\hgs\model\metric\MetricDescriptor.class(com\
realstatus\hgs\model\metric:MetricDescriptor.class)]
    [javac] [loading com\realstatus\hgs\model\metric\MetricValue.class(com\reals
tatus\hgs\model\metric:MetricValue.class)]
    [javac] [loading com\realstatus\hgs\model\metric\TimedValue.class(com\realst
atus\hgs\model\metric:TimedValue.class)]
    [javac] [loading com\realstatus\hgs\model\update\PerformanceModelUpdate.clas
s(com\realstatus\hgs\model\update:PerformanceModelUpdate.class)]
    [javac] [loading java\lang\String.class(java\lang:String.class)]
    [javac] [loading java\lang\Long.class(java\lang:Long.class)]
    [javac] [loading com\realstatus\hgs\collection\dao\PerformanceFetcher.class(
com\realstatus\hgs\collection\dao:PerformanceFetcher.class)]
    [javac] [loading com\realstatus\hgs\model\MetricedEntity.class(com\realstatu
s\hgs\model:MetricedEntity.class)]
    [javac] [loading com\realstatus\hgs\model\enumeration\PeriodEnum.class(com\r
ealstatus\hgs\model\enumeration:PeriodEnum.class)]
    [javac] [loading java\lang\Override.class(java\lang:Override.class)]
    [javac] [loading java\lang\annotation\Annotation.class(java\lang\annotation:
Annotation.class)]
    [javac] [loading javax\xml\bind\annotation\XmlType.class(javax\xml\bind\anno
tation:XmlType.class)]
    [javac] [loading javax\xml\bind\annotation\XmlAccessorType.class(javax\xml\b
ind\annotation:XmlAccessorType.class)]
    [javac] [loading javax\xml\bind\annotation\XmlAccessType.class(javax\xml\bin
d\annotation:XmlAccessType.class)]
    [javac] [loading javax\xml\bind\annotation\XmlAccessorOrder.class(javax\xml\
bind\annotation:XmlAccessorOrder.class)]
    [javac] [loading javax\xml\bind\annotation\XmlAccessOrder.class(javax\xml\bi
nd\annotation:XmlAccessOrder.class)]
    [javac] com\realstatus\hgs\model\metric\DefaultMetricValue.class(com\realsta
tus\hgs\model\metric:DefaultMetricValue.class): warning: Cannot find annotation
method 'alphabetic()' in type 'org.codehaus.jackson.annotate.JsonPropertyOrder':
 class file for org.codehaus.jackson.annotate.JsonPropertyOrder not found
    [javac] com\realstatus\hgs\model\metric\TimedValue.class(com\realstatus\hgs\
model\metric:TimedValue.class): warning: Cannot find annotation method 'alphabet
ic()' in type 'org.codehaus.jackson.annotate.JsonPropertyOrder'
    [javac] [loading java\lang\annotation\Target.class(java\lang\annotation:Targ
et.class)]
    [javac] [loading java\lang\annotation\ElementType.class(java\lang\annotation
:ElementType.class)]
    [javac] [loading java\lang\annotation\Retention.class(java\lang\annotation:R
etention.class)]
    [javac] [loading java\lang\annotation\RetentionPolicy.class(java\lang\annota
tion:RetentionPolicy.class)]
    [javac] [checking com.acme.TopologyDiscoverer]
    [javac] [loading java\util\AbstractMap.class(java\util:AbstractMap.class)]
    [javac] [wrote C:\dev\templatecollector\build\classes\com\acme\TopologyDisco
verer.class]
    [javac] [checking com.acme.metrics.MetricsDiscoverer]
    [javac] [loading java\util\AbstractList.class(java\util:AbstractList.class)]

    [javac] [loading java\util\AbstractCollection.class(java\util:AbstractCollec
tion.class)]
    [javac] [loading java\io\Serializable.class(java\io:Serializable.class)]
    [javac] [loading java\lang\Comparable.class(java\lang:Comparable.class)]
    [javac] [loading java\lang\CharSequence.class(java\lang:CharSequence.class)]

    [javac] [loading com\realstatus\hgs\model\Node.class(com\realstatus\hgs\mode
l:Node.class)]
    [javac] [loading java\lang\Iterable.class(java\lang:Iterable.class)]
    [javac] [loading com\realstatus\hgs\model\metric\AbstractMetricDescriptor.cl
ass(com\realstatus\hgs\model\metric:AbstractMetricDescriptor.class)]
    [javac] [loading java\lang\Double.class(java\lang:Double.class)]
    [javac] [loading java\lang\Number.class(java\lang:Number.class)]
    [javac] [loading java\lang\Byte.class(java\lang:Byte.class)]
    [javac] [loading java\lang\Character.class(java\lang:Character.class)]
    [javac] [loading java\lang\Short.class(java\lang:Short.class)]
    [javac] [loading java\lang\Integer.class(java\lang:Integer.class)]
    [javac] [loading java\lang\Float.class(java\lang:Float.class)]
    [javac] [wrote C:\dev\templatecollector\build\classes\com\acme\metrics\Metri
csDiscoverer$AcmeWidgetPerformanceCollectionRequest.class]
    [javac] [wrote C:\dev\templatecollector\build\classes\com\acme\metrics\Metri
csDiscoverer$AcmeGadgetPerformanceCollectionRequest.class]
    [javac] [wrote C:\dev\templatecollector\build\classes\com\acme\metrics\Metri
csDiscoverer$1.class]
    [javac] [wrote C:\dev\templatecollector\build\classes\com\acme\metrics\Metri
csDiscoverer.class]
    [javac] [checking com.acme.metrics.TimeSeriesMetricsFetcher]
    [javac] [loading java\lang\Math.class(java\lang:Math.class)]
    [javac] [wrote C:\dev\templatecollector\build\classes\com\acme\metrics\TimeS
eriesMetricsFetcher.class]
    [javac] [total 1244ms]
    [javac] 2 warnings

ear.build:
    [mkdir] Created dir: C:\dev\templatecollector\build\templatecollector.ear\ME
TA-INF
     [copy] Copying 6 files to C:\dev\templatecollector\build\templatecollector.
ear
     [copy] Copying 2 files to C:\dev\templatecollector\build\templatecollector.
ear\META-INF

BUILD SUCCESSFUL
Total time: 2 seconds
C:\dev\templatecollector>
